"""Initial full-agent packaging target: read-only deterministic tool execution.

This version establishes the serving contract; LLM orchestration and UC queries
will replace the preview implementation after workspace configuration.
"""
import json
import mlflow.pyfunc
from shared.schemas import TelemetryEvent
from shared.metrics import hrv

class WearableAgentModel(mlflow.pyfunc.PythonModel):
    def predict(self, context, model_input, params=None):
        results = []
        for row in model_input.to_dict(orient='records'):
            events = [TelemetryEvent.model_validate(e) for e in json.loads(row['telemetry_json'])]
            identities = {(e.user_id, e.session_id, e.device_id) for e in events}
            if len(identities) > 1:
                raise ValueError('One user, session, and device per analysis request')
            events = sorted({e.sequence:e for e in events}.values(), key=lambda e:e.sequence)
            rr, previous = [], None
            for event in events:
                if previous is not None and event.sequence != previous+1:
                    rr = []
                if not event.rr_intervals_ms:
                    rr = []
                else:
                    rr.extend(event.rr_intervals_ms)
                previous = event.sequence
            metrics = hrv(rr)
            output = {'mode':'deterministic_preview', 'message':f"Analyzed {len(events)} mock notifications. Historical baselines and workload are unavailable.",
                'metrics':metrics, 'tool_trace':[{'tool':'compute_hrv','status':'completed','result':metrics}],
                'chart_spec':{'chartType':'LineChart','metric':'heart_rate','title':'Session heart rate'}}
            results.append({'response_json':json.dumps(output)})
        return results
